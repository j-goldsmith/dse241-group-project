H-1B Job Market Explorer
Jared Goldsmith
Jillian Jarrett
Akshit Bhatnagar

Original dataset: https://www.kaggle.com/jonamjar/h1b-data-set-2017

Instructions.

1. Run a local webserver such as SimpleHTTPServer in Python2 or http.server in Python3
2. Open index.html

States, counties, and slope plots are all selectable.
Zoom and pan over map with mouse.
